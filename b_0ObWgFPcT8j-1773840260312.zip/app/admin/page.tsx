'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Trash2, Plus, X, Check } from 'lucide-react'
import { TopNav } from '@/components/top-nav'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { AddUserModal } from '@/components/add-user-modal'

interface User {
  id: string
  username: string
  is_admin: boolean
  created_at: string
}

export default function AdminPage() {
  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      username: 'demo_user',
      is_admin: true,
      created_at: new Date().toISOString(),
    },
  ])
  const [showAddModal, setShowAddModal] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const savedUsers = localStorage.getItem('users')
    if (savedUsers) {
      try {
        setUsers(JSON.parse(savedUsers))
      } catch (error) {
        console.error('Error loading users:', error)
      }
    }
  }, [])

  const handleDeleteUser = (userId: string, username: string) => {
    if (username === 'demo_user') {
      alert('You cannot delete the demo user')
      return
    }

    if (window.confirm(`Are you sure you want to delete ${username}?`)) {
      const newUsers = users.filter((u) => u.id !== userId)
      setUsers(newUsers)
      localStorage.setItem('users', JSON.stringify(newUsers))
    }
  }

  const handleAddUser = (username: string, password: string) => {
    const newUser: User = {
      id: Date.now().toString(),
      username,
      is_admin: false,
      created_at: new Date().toISOString(),
    }

    const newUsers = [...users, newUser]
    setUsers(newUsers)
    localStorage.setItem('users', JSON.stringify(newUsers))
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-background">
      <TopNav />

      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Admin Panel</h1>
            <p className="text-muted-foreground mt-2">Manage users and permissions</p>
          </div>
          <Button 
            onClick={() => setShowAddModal(true)}
            size="lg"
            className="gap-2"
          >
            <Plus className="w-5 h-5" />
            Add User
          </Button>
        </div>

        <Card className="border-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl">Users ({users.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {users.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No users found</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b-2">
                      <TableHead className="font-bold">Username</TableHead>
                      <TableHead className="font-bold">Role</TableHead>
                      <TableHead className="font-bold">Created</TableHead>
                      <TableHead className="text-right font-bold">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((u) => (
                      <TableRow key={u.id} className="hover:bg-secondary/50 transition-colors">
                        <TableCell className="font-semibold text-base">{u.username}</TableCell>
                        <TableCell>
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                            u.is_admin 
                              ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300' 
                              : 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                          }`}>
                            {u.is_admin ? 'Admin' : 'User'}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {u.created_at.split('T')[0]}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteUser(u.id, u.username)}
                            disabled={u.username === 'demo_user'}
                            className="gap-2"
                          >
                            <Trash2 className="w-4 h-4" />
                            Delete
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      <AddUserModal 
        open={showAddModal}
        onOpenChange={setShowAddModal}
        onAddUser={handleAddUser}
      />
    </div>
  )
}
