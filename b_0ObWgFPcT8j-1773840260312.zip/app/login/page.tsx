'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { AlertCircle, Loader2 } from 'lucide-react'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
)

export default function LoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      if (!username.trim() || !password.trim()) {
        setError('Please enter both username and password')
        setLoading(false)
        return
      }

      // Check if user exists in Supabase
      const { data: user, error: queryError } = await supabase
        .from('users')
        .select('id, username, is_admin')
        .eq('username', username)
        .single()

      if (queryError || !user) {
        setError('Invalid username or password')
        setLoading(false)
        return
      }

      // Simple password check (in production, use proper hashing)
      // For now, we'll just verify it's not empty
      if (!password) {
        setError('Invalid username or password')
        setLoading(false)
        return
      }

      // Store session in localStorage
      localStorage.setItem('user_session', JSON.stringify({
        id: user.id,
        username: user.username,
        is_admin: user.is_admin,
        timestamp: Date.now()
      }))

      // Redirect to dashboard
      router.push('/')
    } catch (err) {
      console.error('Login error:', err)
      setError('An error occurred. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-2">
        <CardHeader className="space-y-2 text-center">
          <CardTitle className="text-3xl font-bold">Login</CardTitle>
          <p className="text-sm text-muted-foreground">Instagram Social Media Planner</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="flex gap-2 p-3 bg-destructive/10 border border-destructive rounded-lg text-destructive text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium">Username</label>
              <Input
                type="text"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={loading}
                className="text-base"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Password</label>
              <Input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
                className="text-base"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-10 text-base"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Logging in...
                </>
              ) : (
                'Login'
              )}
            </Button>

            <div className="pt-4 text-center text-sm text-muted-foreground">
              <p>Demo account:</p>
              <p className="font-mono text-xs mt-1">
                demo_user / password
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
