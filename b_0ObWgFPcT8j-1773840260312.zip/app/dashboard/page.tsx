'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { TopNav } from '@/components/top-nav'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface InstagramAccount {
  id: string
  username: string
  followers: number
  engagement_rate: number
  posts_count: number
  avg_likes: number
  avg_comments: number
  reach_last_30_days: number
  impressions_last_30_days: number
}

const mockChartData = [
  { date: 'Jan 1', followers: 0, reach: 0 },
  { date: 'Jan 8', followers: 0, reach: 0 },
  { date: 'Jan 15', followers: 0, reach: 0 },
  { date: 'Jan 22', followers: 0, reach: 0 },
  { date: 'Jan 29', followers: 0, reach: 0 },
  { date: 'Feb 5', followers: 0, reach: 0 },
  { date: 'Feb 12', followers: 0, reach: 0 },
]

const topPostsData = [
  { name: 'Post 1', likes: 0, comments: 0 },
  { name: 'Post 2', likes: 0, comments: 0 },
  { name: 'Post 3', likes: 0, comments: 0 },
  { name: 'Post 4', likes: 0, comments: 0 },
  { name: 'Post 5', likes: 0, comments: 0 },
]

const mockAccount: InstagramAccount = {
  id: '1',
  username: '@hibcoworking',
  followers: 0,
  engagement_rate: 0,
  posts_count: 0,
  avg_likes: 0,
  avg_comments: 0,
  reach_last_30_days: 0,
  impressions_last_30_days: 0,
}

export default function StatisticsPage() {
  const [account, setAccount] = useState<InstagramAccount>(mockAccount)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Using mock data for now
    setLoading(false)
  }, [])

  if (!account) {
    return (
      <div className="min-h-screen bg-background">
        <TopNav />
        <div className="p-6 md:p-8">
          <Card>
            <CardContent className="pt-6">
              <p className="text-muted-foreground">No account data available</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <TopNav />
      <div className="p-6 md:p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Statistics</h1>
            <p className="text-muted-foreground mt-1">Instagram Analytics Dashboard</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-primary">@hibcoworking</p>
            <p className="text-sm text-muted-foreground">Business Account</p>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Followers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{account.followers.toLocaleString()}</div>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">+12% this month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Posts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{account.posts_count}</div>
              <p className="text-xs text-muted-foreground mt-1">Lifetime posts</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg Likes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{account.avg_likes.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">Per post</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Engagement Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{account.engagement_rate.toFixed(2)}%</div>
              <p className="text-xs text-muted-foreground mt-1">Overall</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Followers Growth */}
          <Card>
            <CardHeader>
              <CardTitle>Followers Growth</CardTitle>
              <CardDescription>Last 30 days trend</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={mockChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: 'var(--foreground)' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="followers"
                    stroke="var(--primary)"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Reach Trend */}
          <Card>
            <CardHeader>
              <CardTitle>Reach Trend</CardTitle>
              <CardDescription>Last 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={mockChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: 'var(--foreground)' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="reach"
                    stroke="var(--accent)"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Performing Posts */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Top Performing Posts</CardTitle>
              <CardDescription>Most liked and commented posts</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topPostsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--card)',
                      border: '1px solid var(--border)',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: 'var(--foreground)' }}
                  />
                  <Bar dataKey="likes" fill="var(--primary)" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="comments" fill="var(--accent)" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Additional Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Reach (30 days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {account.reach_last_30_days.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Total account reach</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Impressions (30 days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">
                {account.impressions_last_30_days.toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Total impressions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg Comments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{account.avg_comments.toFixed(0)}</div>
              <p className="text-xs text-muted-foreground mt-1">Per post</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
