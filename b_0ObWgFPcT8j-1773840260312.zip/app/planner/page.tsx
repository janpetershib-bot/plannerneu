'use client'

import { useState, useEffect } from 'react'
import { TopNav } from '@/components/top-nav'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight, Plus, Trash2, Loader2 } from 'lucide-react'
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
)

interface Post {
  id: string
  date: string
  type: 'post' | 'story'
  description: string
  image: string | null
  posted: boolean
}

export default function PlannerPage() {
  const [posts, setPosts] = useState<Post[]>([])
  const [currentMonth, setCurrentMonth] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({ 
    type: 'post', 
    description: '',
    image: null as string | null
  })

  useEffect(() => {
    loadPosts()
  }, [])

  const loadPosts = async () => {
    try {
      const userSession = localStorage.getItem('user_session')
      if (!userSession) return

      const user = JSON.parse(userSession)
      const { data, error } = await supabase
        .from('scheduled_posts')
        .select('*')
        .eq('user_id', user.id)

      if (error) {
        console.error('Error loading posts:', error)
        return
      }

      if (data) {
        const formattedPosts = data.map(post => ({
          id: post.id,
          date: post.scheduled_date,
          type: post.post_type,
          description: post.description,
          image: post.image_base64,
          posted: post.is_posted,
        }))
        setPosts(formattedPosts)
      }
    } catch (err) {
      console.error('Error:', err)
    }
  }

  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate()
  const firstDay = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay()
  const monthName = `${currentMonth.toLocaleString('en-US', { month: 'long' })} ${currentMonth.getFullYear()}`

  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1)
  const emptyDays = Array.from({ length: firstDay }, (_, i) => i)

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))
  }

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))
  }

  const handleDateClick = (day: number) => {
    const dateStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    setSelectedDate(dateStr)
    setShowForm(true)
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setFormData({ ...formData, image: reader.result as string })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleAddPost = async () => {
    if (!selectedDate || !formData.description.trim()) {
      alert('Please fill in description')
      return
    }

    setLoading(true)
    try {
      const userSession = localStorage.getItem('user_session')
      if (!userSession) {
        alert('Please log in first')
        return
      }

      const user = JSON.parse(userSession)

      const { data, error } = await supabase
        .from('scheduled_posts')
        .insert({
          user_id: user.id,
          scheduled_date: selectedDate,
          post_type: formData.type,
          description: formData.description,
          image_base64: formData.image,
          is_posted: false,
        })
        .select()

      if (error) {
        console.error('Error saving post:', error)
        alert('Failed to save post')
        return
      }

      if (data && data[0]) {
        const newPost: Post = {
          id: data[0].id,
          date: data[0].scheduled_date,
          type: data[0].post_type,
          description: data[0].description,
          image: data[0].image_base64,
          posted: data[0].is_posted,
        }
        setPosts([...posts, newPost])
      }

      setFormData({ type: 'post', description: '', image: null })
      setShowForm(false)
      setSelectedDate(null)
    } catch (err) {
      console.error('Error:', err)
      alert('An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const handleDeletePost = async (postId: string) => {
    if (!window.confirm('Delete this post?')) return

    try {
      const { error } = await supabase
        .from('scheduled_posts')
        .delete()
        .eq('id', postId)

      if (error) {
        console.error('Error deleting post:', error)
        return
      }

      setPosts(posts.filter(p => p.id !== postId))
    } catch (err) {
      console.error('Error:', err)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <TopNav />
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Content Planner</h1>
          <p className="text-muted-foreground mt-2">Plan your Instagram posts</p>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-2xl">{monthName}</CardTitle>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="icon"
                onClick={handlePrevMonth}
                className="h-10 w-10"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                onClick={handleNextMonth}
                className="h-10 w-10"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-1">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="text-center font-semibold text-sm text-muted-foreground py-2">
                  {day}
                </div>
              ))}
              
              {emptyDays.map((_, i) => (
                <div key={`empty-${i}`} className="aspect-square" />
              ))}
              
              {days.map(day => {
                const dateStr = `${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
                const dayPosts = posts.filter(p => p.date === dateStr)
                const isToday = new Date().toDateString() === new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day).toDateString()
                const isSelected = selectedDate === dateStr
                
                return (
                  <button
                    onClick={() => handleDateClick(day)}
                    key={day}
                    className={`aspect-square p-2 rounded-lg border-2 font-semibold transition-all hover:scale-105 cursor-pointer ${
                      isSelected
                        ? 'bg-primary text-primary-foreground border-primary scale-105'
                        : isToday
                        ? 'bg-blue-100 dark:bg-blue-900/30 border-blue-500 text-foreground'
                        : dayPosts.length > 0
                        ? 'bg-amber-100 dark:bg-amber-900/30 border-amber-500 text-foreground'
                        : 'bg-card border-border text-foreground hover:bg-secondary'
                    }`}
                  >
                    <div className="text-sm">{day}</div>
                    {dayPosts.length > 0 && (
                      <div className="text-xs mt-0.5">{dayPosts.length} post{dayPosts.length > 1 ? 's' : ''}</div>
                    )}
                  </button>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {showForm && selectedDate && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Add Post for {selectedDate}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Post Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full p-2 border border-border rounded-lg bg-background text-foreground"
                >
                  <option value="post">Post</option>
                  <option value="story">Story</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter post description..."
                  className="w-full p-2 border border-border rounded-lg bg-background text-foreground min-h-24"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Upload Image</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={loading}
                  className="w-full p-2 border border-border rounded-lg bg-background text-foreground"
                />
                {formData.image && (
                  <div className="mt-3">
                    <img src={formData.image} alt="Preview" className="max-h-48 rounded-lg" />
                  </div>
                )}
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddPost} disabled={loading} className="flex-1">
                  {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  {loading ? 'Saving...' : 'Add Post'}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowForm(false)
                    setSelectedDate(null)
                    setFormData({ type: 'post', description: '', image: null })
                  }}
                  disabled={loading}
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {posts.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Scheduled Posts ({posts.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {posts.map(post => (
                  <div key={post.id} className="p-3 bg-secondary rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="font-semibold text-sm">{post.date}</div>
                        <div className="text-xs text-muted-foreground">{post.type === 'post' ? 'Post' : 'Story'}</div>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeletePost(post.id)}
                        className="gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Delete
                      </Button>
                    </div>
                    <div className="text-sm mb-2">{post.description}</div>
                    {post.image && (
                      <img src={post.image} alt="Post" className="max-h-32 rounded-lg" />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
