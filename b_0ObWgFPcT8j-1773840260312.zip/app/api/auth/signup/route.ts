import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const { username, password, isAdmin } = await request.json()

    if (!username || !password) {
      return NextResponse.json(
        { message: 'Username and password are required' },
        { status: 400 }
      )
    }

    // Insert new user
    const { data, error } = await supabase
      .from('users')
      .insert({
        username,
        password, // In production, hash this with bcrypt
        is_admin: isAdmin || false,
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json(
        { message: error.message || 'Failed to create user' },
        { status: 400 }
      )
    }

    return NextResponse.json({
      id: data.id,
      username: data.username,
      is_admin: data.is_admin,
    })
  } catch (error) {
    console.error('Signup error:', error)
    return NextResponse.json(
      { message: 'Internal server error' },
      { status: 500 }
    )
  }
}
