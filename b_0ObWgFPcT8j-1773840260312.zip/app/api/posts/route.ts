import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export async function GET(request: NextRequest) {
  try {
    const { data, error } = await supabase
      .from('scheduled_posts')
      .select('*')
      .order('date', { ascending: false })

    if (error) {
      return NextResponse.json({ message: error.message }, { status: 400 })
    }

    return NextResponse.json(data || [])
  } catch (error) {
    console.error('Error fetching posts:', error)
    return NextResponse.json(
      { message: 'Error fetching posts' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { date, type, description, image, posted } = await request.json()

    const { data, error } = await supabase
      .from('scheduled_posts')
      .insert([
        {
          date,
          type,
          description,
          image,
          posted: posted || false,
          account_id: 1,
        },
      ])
      .select()

    if (error) {
      return NextResponse.json({ message: error.message }, { status: 400 })
    }

    return NextResponse.json(data[0])
  } catch (error) {
    console.error('Error creating post:', error)
    return NextResponse.json(
      { message: 'Error creating post' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, date, type, description, image, posted } = await request.json()

    const { data, error } = await supabase
      .from('scheduled_posts')
      .update({
        date,
        type,
        description,
        image,
        posted,
      })
      .eq('id', id)
      .select()

    if (error) {
      return NextResponse.json({ message: error.message }, { status: 400 })
    }

    return NextResponse.json(data[0])
  } catch (error) {
    console.error('Error updating post:', error)
    return NextResponse.json(
      { message: 'Error updating post' },
      { status: 500 }
    )
  }
}
