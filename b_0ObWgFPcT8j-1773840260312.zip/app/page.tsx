'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import DashboardPage from './dashboard/page'

export default function Home() {
  const router = useRouter()
  const [authenticated, setAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    try {
      const userSession = localStorage.getItem('user_session')
      if (!userSession) {
        router.replace('/login')
        return
      }
      setAuthenticated(true)
    } catch (err) {
      console.error('Auth check error:', err)
      router.replace('/login')
    } finally {
      setLoading(false)
    }
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (!authenticated) {
    return null
  }

  return <DashboardPage />
}
