# Instagram Social Media Planner - Getting Started

## Features

Your Instagram Social Media Planner is now fully functional with the following features:

### 1. **Statistics Dashboard** (`/dashboard`)
- View Instagram account analytics for @hibcoworking
- Display followers, total posts, average likes, and engagement rate
- Visual charts showing followers growth and reach trends
- Top performing posts overview

### 2. **Content Planner Calendar** (`/planner`)
- Interactive calendar with full month navigation
- Color-coded posts:
  - **Green**: Posted content
  - **Yellow**: Scheduled content (pending)
  - **Red**: Past due dates
- Click any date to create or edit posts
- Upload images (stored as base64)
- Add descriptions for each post
- Choose between "Post" or "Story" type
- Copy descriptions and download images
- Mark posts as posted with a single click

### 3. **Admin Panel** (`/admin`)
- Add new users with custom usernames and passwords
- View all registered users
- Delete users (can't delete your own account)
- Manage user permissions

### 4. **Theme Support**
- Light and dark mode toggle
- Smooth theme transitions
- Instagram-inspired color scheme with purple and pink accents

## Demo Credentials

The app auto-logs in with a demo user. No login required to get started!

## Data Storage

Currently, all data is stored in browser localStorage:
- Posts and scheduling data
- User information
- Theme preference

**Note:** Data persists across browser sessions but will be cleared if you clear browser storage.

## Navigation

- **Statistics**: View account analytics
- **Planner**: Manage your content calendar
- **Admin**: Add and manage users (top navigation menu)

## To Connect to Supabase (Optional)

If you want to upgrade to real database storage:

1. Create a Supabase account at supabase.com
2. Create a new project
3. Go to Settings → API and copy your credentials
4. Add these environment variables in your project settings:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`

5. Run the database migration scripts to create tables
6. Update the API routes to use Supabase instead of localStorage

## Future Enhancements

- Connect to real Instagram API for live statistics
- Schedule automatic post publishing
- Collaborate with team members
- Custom branding options
- Analytics insights and recommendations
