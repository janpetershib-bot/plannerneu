'use client'

import React, { createContext, useContext, useState, useCallback } from 'react'

interface User {
  id: string
  username: string
  is_admin: boolean
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (username: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  const login = useCallback(async (username: string, password: string) => {
    setLoading(true)
    try {
      // For now, create a demo user without authentication
      const demoUser: User = {
        id: '1',
        username: username || 'demo_user',
        is_admin: true,
      }
      setUser(demoUser)
      localStorage.setItem('user', JSON.stringify(demoUser))
    } finally {
      setLoading(false)
    }
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    localStorage.removeItem('user')
  }, [])

  React.useEffect(() => {
    // Auto-login with demo user on mount
    const stored = localStorage.getItem('user')
    if (stored) {
      try {
        setUser(JSON.parse(stored))
      } catch {
        localStorage.removeItem('user')
      }
    } else {
      // Auto-login with default demo user
      const demoUser: User = {
        id: '1',
        username: 'demo_user',
        is_admin: true,
      }
      setUser(demoUser)
      localStorage.setItem('user', JSON.stringify(demoUser))
    }
    setLoading(false)
  }, [])

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}
