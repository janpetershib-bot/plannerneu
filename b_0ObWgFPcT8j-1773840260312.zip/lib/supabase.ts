import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export async function signIn(username: string, password: string) {
  try {
    // Get user by username
    const { data: users, error: getUserError } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .single()

    if (getUserError || !users) {
      throw new Error('Invalid username or password')
    }

    // For production, use bcrypt to compare passwords
    // For now, we're storing plain passwords (NOT RECOMMENDED for production)
    const passwordMatch = users.password === password

    if (!passwordMatch) {
      throw new Error('Invalid username or password')
    }

    return { user: users, error: null }
  } catch (error) {
    return { user: null, error: error instanceof Error ? error.message : 'Authentication failed' }
  }
}

export async function createUser(username: string, password: string, isAdmin: boolean = false) {
  try {
    const { data, error } = await supabase
      .from('users')
      .insert([
        {
          username,
          password, // In production, hash this with bcrypt
          is_admin: isAdmin,
        },
      ])
      .select()
      .single()

    if (error) throw error

    return { user: data, error: null }
  } catch (error) {
    return { user: null, error: error instanceof Error ? error.message : 'Failed to create user' }
  }
}
