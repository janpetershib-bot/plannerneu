'use client'

import { useState } from 'react'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, addMonths, subMonths } from 'date-fns'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

interface Post {
  id: string
  date: string
  type: 'post' | 'story'
  description: string
  image: string
  posted: boolean
}

interface CalendarViewProps {
  posts: Post[]
  onDateSelect: (date: Date) => void
  onPostClick: (post: Post) => void
}

export function CalendarView({
  posts,
  onDateSelect,
  onPostClick,
}: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date())

  const monthStart = startOfMonth(currentDate)
  const monthEnd = endOfMonth(currentDate)
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd })

  const getPostsForDate = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd')
    return posts.filter((p) => p.date === dateStr)
  }

  const getDateStatus = (date: Date) => {
    const dayPosts = getPostsForDate(date)
    if (dayPosts.length === 0) return null

    const allPosted = dayPosts.every((p) => p.posted)
    const anyPosted = dayPosts.some((p) => p.posted)

    if (allPosted) return 'posted'
    if (anyPosted) return 'partial'
    return 'scheduled'
  }

  const getStatusColor = (status: string | null) => {
    switch (status) {
      case 'posted':
        return 'bg-green-500/20 border-green-500/50'
      case 'scheduled':
        return 'bg-yellow-500/20 border-yellow-500/50'
      case 'partial':
        return 'bg-blue-500/20 border-blue-500/50'
      default:
        return 'border-border/30'
    }
  }

  const getPastDateStyle = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd')
    const now = format(new Date(), 'yyyy-MM-dd')

    if (dateStr < now && !getPostsForDate(date).some((p) => p.posted)) {
      return 'bg-red-500/10 border-red-500/30'
    }

    if (dateStr < now) {
      return getStatusColor(getDateStatus(date))
    }

    return getStatusColor(getDateStatus(date))
  }

  return (
    <div className="space-y-4">
      {/* Month Navigation */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">
          {format(currentDate, 'MMMM yyyy')}
        </h2>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentDate(subMonths(currentDate, 1))}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            onClick={() => setCurrentDate(new Date())}
          >
            Today
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentDate(addMonths(currentDate, 1))}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Calendar Grid */}
      <Card className="border-border/50 p-6">
        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-2 mb-4">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div
              key={day}
              className="text-center font-semibold text-sm text-muted-foreground py-2"
            >
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-2">
          {days.map((date) => {
            const dayPosts = getPostsForDate(date)
            const isTodayDate = isToday(date)
            const status = getDateStatus(date)

            return (
              <div
                key={format(date, 'yyyy-MM-dd')}
                className={`aspect-square p-2 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                  isTodayDate ? 'ring-2 ring-primary' : ''
                } ${getPastDateStyle(date)} ${
                  !isSameMonth(date, currentDate)
                    ? 'opacity-50 pointer-events-none'
                    : ''
                }`}
                onClick={() =>
                  isSameMonth(date, currentDate) && onDateSelect(date)
                }
              >
                <div className="flex flex-col h-full">
                  <span className="text-xs font-semibold text-foreground mb-1">
                    {format(date, 'd')}
                  </span>
                  {dayPosts.length > 0 && (
                    <div className="flex-1 flex flex-col gap-1 overflow-hidden">
                      {dayPosts.slice(0, 2).map((post) => (
                        <button
                          key={post.id}
                          onClick={(e) => {
                            e.stopPropagation()
                            onPostClick(post)
                          }}
                          className={`text-xs px-1.5 py-0.5 rounded truncate font-medium transition-colors ${
                            post.posted
                              ? 'bg-green-500/40 text-green-900 dark:text-green-100 hover:bg-green-500/60'
                              : 'bg-yellow-500/40 text-yellow-900 dark:text-yellow-100 hover:bg-yellow-500/60'
                          }`}
                          title={post.description}
                        >
                          {post.type === 'story' ? '📖' : '📸'} {post.type}
                        </button>
                      ))}
                      {dayPosts.length > 2 && (
                        <span className="text-xs text-muted-foreground">
                          +{dayPosts.length - 2} more
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      {/* Legend */}
      <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-green-500/30 border border-green-500/50" />
          <span>Posted</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-yellow-500/30 border border-yellow-500/50" />
          <span>Scheduled</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-red-500/10 border border-red-500/30" />
          <span>Past Due</span>
        </div>
      </div>
    </div>
  )
}
