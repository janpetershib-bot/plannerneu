'use client'

import { useState, useEffect, useRef } from 'react'
import { format } from 'date-fns'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { FieldGroup, Field, FieldLabel } from '@/components/ui/field'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Download, Copy, Trash2, Image as ImageIcon } from 'lucide-react'

interface Post {
  id: string
  date: string
  type: 'post' | 'story'
  description: string
  image: string
  posted: boolean
}

interface PostModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  selectedDate: Date | null
  post: Post | null
  onSave: (post: Omit<Post, 'id'>) => void
  onDelete: (postId: string) => void
}

export function PostModal({
  open,
  onOpenChange,
  selectedDate,
  post,
  onSave,
  onDelete,
}: PostModalProps) {
  const [type, setType] = useState<'post' | 'story'>('post')
  const [description, setDescription] = useState('')
  const [image, setImage] = useState<string>('')
  const [posted, setPosted] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (post) {
      setType(post.type)
      setDescription(post.description)
      setImage(post.image)
      setPosted(post.posted)
    } else {
      setType('post')
      setDescription('')
      setImage('')
      setPosted(false)
    }
  }, [post, open])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setImage(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSave = () => {
    if (!selectedDate || !image || !description.trim()) {
      alert('Please fill in all fields')
      return
    }

    onSave({
      date: format(selectedDate, 'yyyy-MM-dd'),
      type,
      description,
      image,
      posted,
    })
  }

  const handleCopyDescription = () => {
    navigator.clipboard.writeText(description)
  }

  const handleDownloadImage = () => {
    if (!image) return
    const link = document.createElement('a')
    link.href = image
    link.download = `post-${format(selectedDate || new Date(), 'yyyy-MM-dd')}.png`
    link.click()
  }

  const handleDelete = () => {
    if (post && window.confirm('Are you sure you want to delete this post?')) {
      onDelete(post.id)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {post ? 'Edit Post' : 'New Post'}
            {selectedDate && (
              <span className="text-sm font-normal text-muted-foreground ml-2">
                {format(selectedDate, 'MMMM d, yyyy')}
              </span>
            )}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="details" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="preview">Preview</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-6">
            {/* Post Type */}
            <FieldGroup>
              <Field>
                <FieldLabel>Post Type</FieldLabel>
                <Select value={type} onValueChange={(value: any) => setType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="post">Post</SelectItem>
                    <SelectItem value="story">Story</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
            </FieldGroup>

            {/* Image Upload */}
            <FieldGroup>
              <Field>
                <FieldLabel>Upload Image</FieldLabel>
                <div className="border-2 border-dashed border-border/50 rounded-lg p-6 text-center cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => fileInputRef.current?.click()}>
                  {image ? (
                    <div className="space-y-2">
                      <img
                        src={image}
                        alt="Preview"
                        className="w-32 h-32 object-cover rounded mx-auto"
                      />
                      <p className="text-sm text-muted-foreground">Click to change</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <ImageIcon className="w-8 h-8 mx-auto text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        Click to upload or drag and drop
                      </p>
                      <p className="text-xs text-muted-foreground">
                        PNG, JPG, GIF up to 10MB
                      </p>
                    </div>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </Field>
            </FieldGroup>

            {/* Description */}
            <FieldGroup>
              <Field>
                <FieldLabel>Description / Caption</FieldLabel>
                <Textarea
                  placeholder="Write your post caption here..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                />
              </Field>
            </FieldGroup>

            {/* Posted Status */}
            <FieldGroup>
              <Field>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="posted"
                    checked={posted}
                    onCheckedChange={(checked) => setPosted(checked as boolean)}
                  />
                  <FieldLabel className="mb-0 cursor-pointer" htmlFor="posted">
                    Mark as Posted
                  </FieldLabel>
                </div>
              </Field>
            </FieldGroup>
          </TabsContent>

          <TabsContent value="preview" className="space-y-6">
            {image ? (
              <div className="space-y-4">
                <div className="bg-card border border-border/50 rounded-lg overflow-hidden">
                  <img src={image} alt="Preview" className="w-full h-auto" />
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <p className="text-sm font-semibold text-muted-foreground mb-2">
                    Caption:
                  </p>
                  <p className="text-sm whitespace-pre-wrap">{description}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyDescription}
                    className="flex-1"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Caption
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDownloadImage}
                    className="flex-1"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Upload an image to preview</p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter className="gap-2 sm:gap-0">
          {post && (
            <Button
              variant="destructive"
              onClick={handleDelete}
              className="sm:mr-auto"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </Button>
          )}
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            {post ? 'Update Post' : 'Save Post'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
