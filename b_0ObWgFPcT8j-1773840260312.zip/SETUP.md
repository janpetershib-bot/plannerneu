# Instagram Social Media Planner - Setup Guide

## Prerequisites

- Node.js 18+ and pnpm
- Supabase account with a PostgreSQL database

## Installation Steps

1. **Install Dependencies**
   ```bash
   pnpm install
   ```

2. **Setup Supabase**
   - Create a new Supabase project
   - Get your `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`

3. **Configure Environment Variables**
   Create a `.env.local` file in the root directory:
   ```
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

4. **Run Database Migrations**
   The database schema has been set up in Supabase with the following tables:
   - `users` - User accounts with authentication
   - `instagram_accounts` - Instagram account information
   - `scheduled_posts` - Content calendar posts with images (base64) and descriptions

5. **Start Development Server**
   ```bash
   pnpm dev
   ```

6. **Access the Application**
   - Open `http://localhost:3000`
   - Login with demo credentials:
     - Username: `petersjan`
     - Password: `Jallo123@`

## Features

### Authentication
- Username/password login
- Admin accounts for user management

### Statistics Dashboard
- View Instagram account statistics for @hibcoworking
- Track followers, reach, impressions, engagement, likes, comments, and saves

### Content Planner
- Interactive calendar with date-based post management
- Color-coded posts:
  - 🟢 Green: Posted
  - 🟡 Yellow: Scheduled
  - 🔴 Red: Past due
- Upload images (stored as base64 in database)
- Add descriptions/captions
- Copy caption to clipboard
- Download uploaded images
- Toggle post status (scheduled/posted)

### Admin Panel
- Add new users with username and password
- Delete users (cannot delete own account)
- View all users and their roles

### Theme Support
- Dark/Light mode toggle
- Theme persists across sessions
- Instagram-inspired color scheme

## Database Schema

### users
- id: UUID (primary key)
- username: VARCHAR (unique)
- password_hash: VARCHAR
- is_admin: BOOLEAN
- created_at: TIMESTAMP

### instagram_accounts
- id: UUID (primary key)
- user_id: UUID (foreign key)
- account_name: VARCHAR
- followers: INTEGER
- reach: INTEGER
- impressions: INTEGER
- engagement: INTEGER
- engagement_rate: FLOAT

### scheduled_posts
- id: UUID (primary key)
- account_id: UUID (foreign key)
- date: DATE
- type: VARCHAR (post/story)
- description: TEXT
- image: TEXT (base64)
- posted: BOOLEAN
- created_at: TIMESTAMP

## Development

### Create a New User (via Admin Panel)
1. Login as admin (petersjan)
2. Go to Admin Panel
3. Click "Add User"
4. Enter username and password
5. New user can login with those credentials

### Add a Post
1. Go to Planner
2. Click on a date on the calendar
3. Select post type (Post or Story)
4. Upload an image
5. Add a caption/description
6. Save the post
7. Post appears on the calendar as yellow (scheduled)
8. Click "Mark as Posted" to mark it as posted (turns green)

### Deploy to Vercel

1. Push your code to GitHub
2. Connect to Vercel
3. Add environment variables in Vercel dashboard:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Deploy!
