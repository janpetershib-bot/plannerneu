-- Create initial demo user for testing
-- Username: demo_user, Password: password

INSERT INTO public.users (id, username, password_hash, email, is_admin, created_at, updated_at)
VALUES (
  gen_random_uuid(),
  'demo_user',
  'password',
  'demo@example.com',
  true,
  now(),
  now()
)
ON CONFLICT (username) DO NOTHING;

-- Create default Instagram account for demo user
INSERT INTO public.instagram_accounts (id, user_id, username, followers, engagement_rate, posts_count, reach, impressions, is_default, created_at, updated_at)
SELECT
  gen_random_uuid(),
  u.id,
  '@hibcoworking',
  0,
  0,
  0,
  0,
  0,
  true,
  now(),
  now()
FROM public.users u
WHERE u.username = 'demo_user'
ON CONFLICT DO NOTHING;
