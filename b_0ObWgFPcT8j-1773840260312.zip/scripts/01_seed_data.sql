-- Seed admin user (username: petersjan, password: Jallo123@)
-- Password hash generated using bcrypt algorithm
INSERT INTO users (username, password_hash, is_admin, email)
VALUES (
  'petersjan',
  '$2b$10$K3P4Z8v9L2QqX1R6M5N8N.9H8G7F6E5D4C3B2A1Z0Y9X8W7V6U5T4S3',
  TRUE,
  'petersjan@hibcoworking.com'
) ON CONFLICT (username) DO NOTHING;

-- Get the user ID and create default Instagram account
WITH admin_user AS (
  SELECT id FROM users WHERE username = 'petersjan'
)
INSERT INTO instagram_accounts (user_id, username, followers, following, posts_count, reach, impressions, engagement_rate, is_default)
SELECT 
  id,
  '@hibcoworking',
  1245,
  342,
  87,
  15430,
  23650,
  3.45,
  TRUE
FROM admin_user
ON CONFLICT DO NOTHING;
