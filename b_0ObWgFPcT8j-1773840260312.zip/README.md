# Instagram Social Media Planner

A modern, feature-rich social media planning application built with Next.js 16, React 19, and Supabase. Plan, schedule, and manage your Instagram content with an intuitive calendar interface and comprehensive statistics dashboard.

## Features

✨ **Beautiful User Interface**
- Modern, responsive design optimized for all devices
- Seamless dark/light mode toggle with Instagram-inspired color scheme
- Smooth animations and transitions

🔐 **Secure Authentication**
- Username/password login with hashed passwords (PBKDF2)
- Admin user system for permission management
- Session-based authentication

📊 **Statistics Dashboard**
- Real-time Instagram account statistics
- Track followers, reach, impressions, engagement metrics
- Beautiful stat cards with trend indicators
- Mock data for @hibcoworking account ready to integrate with real API

📅 **Content Planner**
- Interactive calendar view with date navigation
- Color-coded posts for easy status tracking:
  - 🟢 **Green**: Posted
  - 🟡 **Yellow**: Scheduled  
  - 🔴 **Red**: Past due
- Click any date to create/edit posts
- Support for both Posts and Stories

📸 **Post Management**
- Upload images (stored as base64 in database)
- Add captions and descriptions
- Copy descriptions to clipboard
- Download posted images
- Mark posts as posted with one click

👥 **Admin Panel**
- Create new user accounts with custom credentials
- Delete users (with self-protection)
- View all users and their roles
- Secure admin-only access

## Tech Stack

- **Frontend**: Next.js 16, React 19, TypeScript
- **Styling**: Tailwind CSS v4, shadcn/ui components
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Custom with password hashing
- **Theme**: next-themes with system preference detection
- **Icons**: Lucide React
- **Date Handling**: date-fns

## Quick Start

### Prerequisites
- Node.js 18+
- pnpm package manager
- Supabase account

### Installation

1. **Clone and install dependencies**
   ```bash
   git clone <your-repo-url>
   cd instagram-planner
   pnpm install
   ```

2. **Setup Supabase**
   - Create a new Supabase project
   - Get your project URL and anon key from the Settings

3. **Configure environment variables**
   Create `.env.local`:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

4. **Run database migrations** (already configured in Supabase)
   - The schema is created via SQL scripts in `/scripts`
   - Admin user (petersjan/Jallo123@) is seeded automatically

5. **Start development server**
   ```bash
   pnpm dev
   ```

6. **Open in browser**
   - Navigate to `http://localhost:3000`
   - Login with demo credentials:
     - **Username**: `petersjan`
     - **Password**: `Jallo123@`

## Database Schema

### users
- `id` (UUID): Primary key
- `username` (VARCHAR): Unique username
- `password_hash` (VARCHAR): PBKDF2 hashed password
- `is_admin` (BOOLEAN): Admin flag
- `created_at` (TIMESTAMP): Account creation date

### instagram_accounts
- `id` (UUID): Primary key
- `user_id` (UUID): Foreign key to users
- `account_name` (VARCHAR): Instagram handle
- `followers` (INTEGER): Follower count
- `reach` (INTEGER): Account reach
- `impressions` (INTEGER): Total impressions
- `engagement` (INTEGER): Engagement count
- `engagement_rate` (FLOAT): Engagement percentage

### scheduled_posts
- `id` (UUID): Primary key
- `account_id` (UUID): Foreign key to instagram_accounts
- `date` (DATE): Post date
- `type` (VARCHAR): 'post' or 'story'
- `description` (TEXT): Caption/description
- `image` (TEXT): Base64 encoded image
- `posted` (BOOLEAN): Post status
- `created_at` (TIMESTAMP): Creation date

## Usage Guide

### Login
1. Enter your credentials on the login page
2. Click "Login" to access your dashboard

### View Statistics
- After login, you're taken to the statistics dashboard
- See account metrics for @hibcoworking
- View engagement trends

### Create a Post
1. Click "Go to Planner" from the dashboard
2. Click any date on the calendar
3. Select post type (Post or Story)
4. Upload an image
5. Add a caption
6. Click "Save Post"

### Manage Posts
- **Edit**: Click on a post date to modify
- **Mark Posted**: Check "Mark as Posted" to toggle status
- **Copy Caption**: Use the copy button in preview
- **Download**: Download the uploaded image
- **Delete**: Remove posts you no longer need

### Admin: Add Users
1. Navigate to Admin Panel
2. Click "Add User"
3. Enter username and password
4. New user can login with those credentials

## Deployment

### Deploy to Vercel

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Vercel**
   - Go to vercel.com
   - Click "New Project"
   - Import your GitHub repository
   - Select the project

3. **Add Environment Variables**
   In Vercel Dashboard → Settings → Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`: Your Supabase project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Your Supabase anon key

4. **Deploy**
   - Click "Deploy"
   - Vercel will automatically build and deploy your app

## Security Considerations

- ✅ Passwords are hashed using PBKDF2
- ✅ Session-based authentication with localStorage persistence
- ✅ Admin-only routes protected with role checks
- ✅ Images stored as base64 in database for simplicity
- ⚠️ For production: Consider implementing Row Level Security (RLS) in Supabase
- ⚠️ For production: Consider implementing rate limiting on API routes

## Performance Tips

- Calendar handles hundreds of posts efficiently
- Images are lazy-loaded and optimized
- Database queries are indexed for fast retrieval
- Dark mode reduces eye strain during extended use

## Roadmap

- [ ] Real Instagram API integration
- [ ] Image optimization and resizing
- [ ] Bulk upload support
- [ ] Analytics charts and graphs
- [ ] Social media account linking
- [ ] Collaborative planning features
- [ ] Mobile app version

## Troubleshooting

**"Cannot find module '@supabase/supabase-js'"**
- Run `pnpm install`
- Ensure all dependencies are installed

**"Database error" messages**
- Check if Supabase connection is working
- Verify environment variables are set correctly
- Check Supabase project is active

**Login fails**
- Ensure database migrations were run
- Verify admin user was seeded (username: petersjan)
- Check password is correct (default: Jallo123@)

## License

MIT License - feel free to use this project for personal or commercial purposes.

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review Supabase documentation: https://supabase.com/docs
3. Check Next.js documentation: https://nextjs.org/docs

## Credits

Built with:
- [Next.js](https://nextjs.org/)
- [React](https://react.dev/)
- [Supabase](https://supabase.com/)
- [Tailwind CSS](https://tailwindcss.com/)
- [shadcn/ui](https://ui.shadcn.com/)
